import {test} from 'node:test';
import {Readable} from 'node:stream';

async function fetchLocal(server,url,options={}) {
 const req=Readable.from(options.body?[options.body]:[]);
 req.url=new URL(url).pathname+new URL(url).search;req.method=options.method||'GET';req.headers=Object.fromEntries(Object.entries(options.headers||{}).map(([k,v])=>[k.toLowerCase(),v]));req.headers.host='localhost';
 return new Promise(resolve=>{const headers={};const res={statusCode:200,setHeader(k,v){headers[k]=v;},end(body){resolve(new Response(body,{status:this.statusCode,headers}));}};server.emit('request',req,res);});
}

import assert from 'node:assert/strict';
import {createGameServer} from './server.mjs';
import {questions} from './questions.mjs';

test('Beş oyuncuyla oda, yetkiler, cevap gizliliği ve tam oyun',async()=>{
 const server=createGameServer({questionMs:1000,revealMs:10});const fetch=(url,options)=>fetchLocal(server,url,options);
 const base='http://localhost';
 async function call(path,data,token){const res=await fetch(base+'/api/'+path,{method:data?'POST':'GET',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:data?JSON.stringify(data):undefined});return {status:res.status,body:await res.json()};}
 try{
  const host=(await call('create',{name:'Ada'})).body;const players=[host];
  assert.equal((await call('start',{code:host.code},host.token)).status,400);
  for(let i=1;i<5;i++)players.push((await call('join',{name:'Oyuncu '+i,code:host.code})).body);
  assert.equal((await call('join',{name:'Altıncı',code:host.code})).status,400);
  assert.equal((await call('start',{code:host.code},players[1].token)).status,403);
  assert.equal((await call('state?code='+host.code,null,players[1].state.me)).status,401);
  let s=(await call('start',{code:host.code},host.token)).body;
  assert.equal(s.correct,null);assert.equal(s.players.length,5);
  assert.ok(!JSON.stringify(s).includes(host.token));
  assert.equal((await call('join',{name:'Geç',code:host.code})).status,400);
  for(let index=0;index<10;index++){
   assert.equal(s.phase,'question');assert.equal(s.index,index);
   const q=questions.find(q=>q[0]===s.question.text);
   assert.equal((await call('answer',{code:host.code,index,choice:7},host.token)).status,400);
   for(let i=0;i<players.length;i++){
    const choice=i===0?q[2]:(q[2]+1)%4;
    const r=await call('answer',{code:host.code,index,choice},players[i].token);assert.equal(r.status,200);s=r.body;
    if(i===0){assert.equal(s.correct,null);assert.equal((await call('answer',{code:host.code,index,choice},host.token)).status,400);}
   }
   assert.equal(s.phase,'reveal');assert.equal(s.correct,q[2]);
   await new Promise(r=>setTimeout(r,20));s=(await call('state?code='+host.code,null,host.token)).body;
  }
  assert.equal(s.phase,'finished');assert.ok(s.players[0].score>=5000);assert.ok(s.players.slice(1).every(p=>p.score===0));
  s=(await call('start',{code:host.code},host.token)).body;assert.equal(s.phase,'question');assert.ok(s.players.every(p=>p.score===0));
  const html=await fetch(base+'/');assert.equal(html.status,200);assert.match(await html.text(),/Bilgi Arena/);
 }finally{server.emit('close');}
});

test('Cevap vermeyen oyuncularla süre dolması',async()=>{
 const server=createGameServer({questionMs:30,revealMs:10});const fetch=(url,options)=>fetchLocal(server,url,options);
 const base='http://localhost';
 const post=async(path,data,token)=>{const r=await fetch(base+'/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(data)});return {status:r.status,body:await r.json()};};
 try{const h=(await post('create',{name:'Host'})).body;for(let i=0;i<3;i++)await post('join',{name:'P'+i,code:h.code});await post('start',{code:h.code},h.token);await new Promise(r=>setTimeout(r,40));const late=await post('answer',{code:h.code,index:0,choice:0},h.token);assert.equal(late.status,400);const res=await fetch(base+'/api/state?code='+h.code,{headers:{Authorization:'Bearer '+h.token}});const s=await res.json();assert.equal(s.phase,'reveal');assert.ok(s.players.every(p=>p.score===0));}finally{server.emit('close');}
});

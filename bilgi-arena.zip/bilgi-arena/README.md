# Bilgi Arena

Telefon tarayıcısında oynanan, 4–5 kişilik online bilgi ve hız yarışması. Node.js 22 veya üstü yeterlidir; bağımlılık kurulumu gerekmez.

## Çalıştırma

```sh
npm start
```

Sunucu varsayılan olarak 3000 portunda dinler. `PORT` ile değiştirilebilir. Yerel deneme: `http://localhost:3000`. Aynı ağdaki telefonlar bilgisayarın yerel IP adresini kullanabilir. Farklı ağlardan online oynamak için uygulama, HTTPS sağlayan bir Node.js sunucusuna yayımlanmalıdır. Bu çalışma henüz internete yayımlanmadı.

Bir oyuncu oda açar, diğerleri aynı adreste oda koduyla katılır. 4 kişi gelince oda sahibi başlatır; en fazla 5 kişi katılabilir. 10 soru, soru başına 15 saniye. Doğru cevap 500 temel puan ve hıza bağlı en fazla 500 ek puan kazandırır. Yanlış veya boş cevap sıfır puandır. Soru ve puanlar sunucuda tutulur; cevap anahtarı soru bitmeden gönderilmez.

## Testler

```sh
npm test
```

## İlk sürüm sınırları

Odalar tek sunucunun belleğinde tutulur. Yeniden başlatma odaları siler; birden fazla sunucu örneği için ortak veritabanı gerekir. Kullanıcı hesapları, oyuncu çıkarma ve otomatik ayrılma yoktur; ayrılan oyuncu tur bitene kadar listede kalır. Sekmeyi yenilemek oturumu korur. İki saat etkinlik olmayan odalar temizlenir. Durum 700 ms aralıkla güncellenir; WebSocket kullanılmaz. Yayın öncesinde gerçek telefon ve erişilebilirlik testleri, trafik sınırlaması ve kalıcı oda depolaması önerilir.
